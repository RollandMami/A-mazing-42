"""Define display, window, and layout configuration constants for the GUI."""

WINDOW_WIDTH = 700
WINDOW_HEIGHT = 800
WINDOW_TITLE = "A-Maze-ing"
BACKGROUND_COLOR = 0x202020
CELL_SIZE = 48
FPS = 60
MARGIN = 20
MAZE_NBR = 50
