#!/usr/bin/env python3
"""Module for handling user input events and window signals.

This module intercepts keyboard inputs and MiniLibX window destruction events,
dispatching appropriate actions to control the maze application interface.
"""

from typing import Any
from gui import colors as colors_module
import colorsys


class EventHandler:
    """Manages input hooks, key bindings, and window callbacks for MiniLibX.

    This handler translates keypresses into maze control actions (regenerating,
    toggling paths, cycling color themes, or exiting the application).
    """

    def __init__(self,
                 mlx_instance: Any,
                 mlx_ptr: Any,
                 win_ptr: Any,
                 window: Any) -> None:
        """Initialize event handler with MiniLibX instances & window reference.

        Args:
            mlx_instance: The PatchedMlx wrapper instance.
            mlx_ptr: Pointer to the initialized MiniLibX instance.
            win_ptr: Pointer to the active MiniLibX window instance.
            window: Reference to the parent Window controller object.
        """
        self.mlx = mlx_instance
        self.mlx_ptr = mlx_ptr
        self.win_ptr = win_ptr
        self.window = window
        self._bindings = {
            65307: lambda: self.mlx.mlx_loop_exit(self.mlx_ptr),
            ord('r'): self.window.regenerate_maze,
            ord('R'): self.window.regenerate_maze,
            ord('p'): self.window.toggle_path,
            ord('P'): self.window.toggle_path,
            ord('c'): self._cycle_wall_color,
            ord('C'): self._cycle_wall_color,
            ord('s'): self.window.show_config,
            ord('S'): self.window.show_config,
            ord('a'): self.window.toggle_animation,
            ord('A'): self.window.toggle_animation,
            ord('l'): self._cycle_42_color,
            ord('L'): self._cycle_42_color,
        }

    def setup_hooks(self) -> None:
        """Register keyboard and window-close event hooks."""
        self.mlx.mlx_key_hook(self.win_ptr, self._on_key, None)
        self.mlx.mlx_hook(self.win_ptr, 33, 0, self._on_destroy, None)

    def _on_destroy(self, param: Any) -> None:
        """Handle the window-close (WM_DELETE_WINDOW) event.

        Args:
            param: Optional parameter passed by the MiniLibX event hook.
        """
        print("Windows closed succesfuly!")
        self.mlx.mlx_loop_exit(self.mlx_ptr)

    def _on_key(self, keycode: int, param: Any) -> None:
        """Dispatche a keypress event to its bound callback function.

        Args:
            keycode: Key code integer sent by the MiniLibX keypress hook.
            param: Optional parameter passed by the MiniLibX event hook.
        """
        action = self._bindings.get(keycode)
        if action:
            try:
                action()
            except Exception as e:
                print("Erreur pendant l'action clavier",
                      f" : {type(e).__name__}: {e}", sep="")

    def _hex_to_rgb(self, color: int) -> tuple[float, float, float]:
        """Convert a 24-bit hexadecimal color to normalized RGB.

        Args:
            color: Color value encoded as a 24-bit integer (0xRRGGBB).

        Returns:
            A tuple of (r, g, b) floats, each normalized to the range
            [0.0, 1.0].
        """
        r = (color >> 16) & 0xFF
        g = (color >> 8) & 0xFF
        b = color & 0xFF
        return r / 255, g / 255, b / 255

    def _rgb_to_hex(self, r: float, g: float, b: float) -> int:
        """Convert normalized RGB values to a 24-bit hexadecimal color.

        Each component is clamped to [0.0, 1.0] before conversion, then
        scaled to the [0, 255] integer range.

        Args:
            r: Red component, normalized in the range [0.0, 1.0].
            g: Green component, normalized in the range [0.0, 1.0].
            b: Blue component, normalized in the range [0.0, 1.0].

        Returns:
            Color value encoded as a 24-bit integer (0xRRGGBB).
        """
        r, g, b = [max(0, min(255, round(x * 255))) for x in (r, g, b)]
        return (r << 16) | (g << 8) | b

    def _adjust_lightness(self, color: int, delta: float) -> int:
        """Adjust the lightness of a color while preserving hue and saturation.

        Converts the color to the HLS color space, shifts its lightness by
        ``delta``, clamps the result to a valid range, and converts back to
        a 24-bit hexadecimal color.

        Args:
            color: Color value encoded as a 24-bit integer (0xRRGGBB).
            delta: Amount to shift the lightness by, in the range
                [-1.0, 1.0]. Positive values lighten the color, negative
                values darken it.

        Returns:
            The adjusted color, encoded as a 24-bit integer (0xRRGGBB).
        """
        r, g, b = self._hex_to_rgb(color)
        h, l, s = colorsys.rgb_to_hls(r, g, b)
        light = max(0.0, min(1.0, l + delta))
        r, g, b = colorsys.hls_to_rgb(h, light, s)
        return self._rgb_to_hex(r, g, b)

    def _cycle_wall_color(self) -> None:
        """Cycle through predefined wall col_palettes & re-renders the maze."""
        palette = colors_module.PALETTE

        current = colors_module.WALL_COLOR
        idx = 0
        for i, c in enumerate(palette):
            if self._adjust_lightness(c, 0.25) == current:
                idx = (i + 1) % len(palette)
                break
        hue = palette[idx]
        colors_module.WALL_COLOR = self._adjust_lightness(hue, 0.25)
        print("\033c", end="")
        print(f"Wall color changed : #{palette[idx]:06X}")
        self.window.render()

    def _cycle_42_color(self) -> None:
        """Cycle through predefined 42 col_palettes & re-renders the maze."""
        palette = colors_module.PALETTE

        current = colors_module.FORTY_TWO_COLOR
        idx = 0
        for i, c in enumerate(palette):
            if self._adjust_lightness(c, 0.25) == current:
                idx = (i + 1) % len(palette)
                break
        hue = palette[idx]
        colors_module.FORTY_TWO_COLOR = self._adjust_lightness(hue, 0.25)
        print("\033c", end="")
        print(f"42 color changed : #{palette[idx]:06X}")
        self.window.render()
