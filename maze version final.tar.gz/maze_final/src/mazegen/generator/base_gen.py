"""Abstract class ("42" mask, imperfections, export)."""

import random
from abc import ABC, abstractmethod
from typing import List, Tuple, Optional, Protocol
from ..solver import BfsSolver
from ..infrastructure import Config, BaseWriter, TxtWriter


class Solver(Protocol):
    """Protocol defining the interface for maze solving algorithms.

    Classes implementing this protocol must provide a mechanism to find a path
    through a grid-based maze from a starting point to an endpoint.
    """

    def solve(self, grid: List[List[int]],
              start: Tuple[int, int],
              end: Tuple[int, int]
              ) -> Optional[tuple[List[Tuple[int, int]], str]]:
        """Solve the maze for a given grid, start, and end positions.

        Args:
            grid: A 2D list of integers representing the maze
            structure where each cell value contains wall
            data (bitwise representation).
            start: A tuple of (column, row) representing the
            starting coordinates.
            end: A tuple of (column, row) representing the target
            destination coordinates.

        Returns:
            A tuple containing:
                - List[Tuple[int, int]]: The path from start to end
                as a list of (column, row) coordinate tuples.
                - str: A string representing the directions
                or metadata of the path.
            Returns None if no valid path exists between start and end.
        """
        ...


class BaseGen(ABC):
    """Abstract base class for maze generators.

    Provides common functionality for initializing maze grids, handling
    configurations, applying masks (such as the 42 logo), introducing
    imperfections (loops), solving, and exporting the generated maze.

    Attributes:
        output_file (str): Path to the destination file where
        the maze is exported.
        maze (List[List[int]]): 2D grid representing the maze.
        Each cell value is a bitwise integer representation of its walls.
    """

    def __init__(self,
                 cfg: Config,
                 writer: BaseWriter,
                 solver: Solver = BfsSolver()
                 ) -> None:
        """Initialize the maze generator with configuration, writer & solver.

        Args:
            cfg: Configuration object containing dimensions, entry/exit points,
                seed, and target output path.
            writer: File writer instance responsible for exporting maze data.
            solver: Algorithm solver implementation used to
            resolve the maze path.
        """
        self._width: int = cfg.width
        self._height: int = cfg.height
        self._entry: tuple[int, int] = cfg.entry_pt
        self._exit: tuple[int, int] = cfg.exit_pt
        self.output_file: str = cfg.output_file
        self._perfect: bool = cfg.perfect
        self._algorithm = cfg.algorithm
        self._algo_name = cfg.algorithm_name
        self._seed: int | None = cfg.seed
        self.maze: List[List[int]] = [
            [15 for _ in range(self._width)] for _ in range(self._height)
        ]
        self._direction: dict[str, tuple[int, ...]] = {
            "N": (0, -1, 0),
            "E": (1, 0, 1),
            "S": (0, 1, 2),
            "O": (-1, 0, 3)
        }
        self._size: int = self._height * self._width
        self._min_logo_size: int = 12 * 8
        self._writer = writer if writer else TxtWriter()
        self._solver = solver
        self._mask_42: Optional[list[tuple[int, int]]] = None
        if self._seed is None:
            self._seed = random.randint(0, 999)
        if self._size >= self._min_logo_size:
            self._mask_42 = self._apply_mask()
            if self.entry in self._mask_42 or self.exit in self._mask_42:
                log_level = "[ENTRY || EXIT]"
                error_message = "\nThe point collide to the 42 logo"
                raise ValueError(log_level+error_message)
        else:
            print("[LOGO ERROR]: The maze dimension is too small for 42 logo")
        self._solution: Optional[tuple[List[Tuple[int, int]], str]] = None
        self._generated: bool = False

    def _finalize(self) -> None:
        """Finalize the generation process.

        Applies imperfections if the maze is not configured to be perfect,
        marks the maze as generated, and resets cached solutions.
        Must be called by subclasses at the end of their `generate()` method.
        """
        if self._perfect is False:
            self._make_imperfection()
        self._generated = True
        self._solution = None

    def export(self) -> None:
        """Export the maze, its metadata & solution to the output file.

        Raises:
            RuntimeError: If called before `generate()`
            or if no valid path exists
                between the entry and exit points.
        """
        if not self._generated:
            raise RuntimeError(
                "Cannot export before generate() has been called"
            )
        self._writer.write(self.maze, self.output_file)
        meta: str = f"\n{self._entry}\n{self._exit}"
        self._writer.insert(meta, self.output_file)
        solution = self.solution
        if solution is None:
            raise RuntimeError(
                "Maze has no valid solution between entry and exit"
            )
        res = solution[1]
        solution_str: str = f"\n{res}"
        self._writer.insert(solution_str, self.output_file)

    def _apply_mask(self) -> List[Tuple[int, int]]:
        """Calculate coordinates for the central '42' logo mask.

        Returns:
            List[Tuple[int, int]]: Coordinates offset
            to center the '42' pattern
            within the maze dimensions.
        """
        coords: List[Tuple[int, int]] = [
            (-3, -2), (-3, -1), (-3, 0), (-2, 0),
            (-1, 0), (-1, 1), (-1, 2),
            (1, -2), (2, -2), (3, -2), (3, -1),
            (3, 0), (2, 0), (1, 0), (1, 1),
            (1, 2), (2, 2), (3, 2)
        ]
        middle_x: int = self.width // 2
        middle_y: int = self.height // 2
        return [
            (point[0] + middle_x, point[1] + middle_y) for point in coords
            ]

    def _make_imperfection(self) -> None:
        """Remove random internal walls to create loops in non-perfect mazes.

        Removes approximately 10% of potential internal walls while explicitly
        preserving walls around cells that form part of the '42' logo mask.
        """
        walls_to_break: int = int(self.width * self.height * 0.1)
        opposites: dict[str, str] = {"N": "S", "S": "N", "E": "O", "O": "E"}
        for _ in range(walls_to_break):
            rx: int = random.randint(1, self.width - 2)
            ry: int = random.randint(1, self.height - 2)
            if self._mask_42 is not None and (rx, ry) in self._mask_42:
                continue
            dir_name: str = random.choice(list(self.direction.keys()))
            dx, dy, bit_idx = self.direction[dir_name]
            nx: int = rx + dx
            ny: int = ry + dy
            if self._mask_42 is not None and (nx, ny) in self._mask_42:
                continue
            power: int = 2 ** bit_idx
            if (self.maze[ry][rx] // power) % 2 == 1:
                if self._would_create_open_area(rx, ry, nx, ny, dir_name):
                    continue
                self.maze[ry][rx] -= power
                opp_dir: str = opposites[dir_name]
                opp_bit: int = self.direction[opp_dir][2]
                self.maze[ny][nx] -= (2 ** opp_bit)

    def _cell_wall_open(self, x: int, y: int, dir_name: str,
                        ignore: tuple[int, int, str] | None = None
                        ) -> bool:
        """Return True if the wall in dir_name from (x, y) is already open.

        Or would be open if it matches the 'ignore' wall (simulated break).
        """
        if ignore is not None and (x, y, dir_name) == ignore:
            return True
        _, _, bit_idx = self.direction[dir_name]
        power: int = 2 ** bit_idx
        return (self.maze[y][x] // power) % 2 == 0

    def _block_fully_open(self, bx: int, by: int,
                          ignore: tuple[int, int, str]) -> bool:
        """Check whether the 3x3 block anchored at (bx, by).

        Would be entirely open (all 12 internal walls removed).
        """
        for y in range(by, by + 3):
            for x in range(bx, bx + 2):
                if not self._cell_wall_open(x, y, "E", ignore):
                    return False
        for x in range(bx, bx + 3):
            for y in range(by, by + 2):
                if not self._cell_wall_open(x, y, "S", ignore):
                    return False
        return True

    def _would_create_open_area(self, rx: int, ry: int,
                                nx: int, ny: int, dir_name: str) -> bool:
        """Return True if breaking the wall between (rx, ry) and (nx, ny).

        Would create a fully open 3x3 (or larger) area.
        """
        cx, cy = min(rx, nx), min(ry, ny)
        canonical_dir: str = "E" if ry == ny else "S"
        ignore = (cx, cy, canonical_dir)

        for bx in range(max(0, cx - 2), min(self.width - 3, cx) + 1):
            for by in range(max(0, cy - 2), min(self.height - 3, cy) + 1):
                if self._block_fully_open(bx, by, ignore):
                    return True
        return False

    @property
    def entry(self) -> tuple[int, int]:
        """tuple[int, int]: Coordinates (column, row) of the maze entrance."""
        return self._entry

    @property
    def exit(self) -> tuple[int, int]:
        """tuple[int, int]: Coordinates (column, row) of the maze exit."""
        return self._exit

    @property
    def mask_42(self) -> list[tuple[int, int]] | None:
        """Optional[list[tuple[int, int]]]: Coords of the '42' logo cells."""
        return self._mask_42

    @property
    def width(self) -> int:
        """int: Width (number of columns) of the maze."""
        return self._width

    @property
    def height(self) -> int:
        """int: Height (number of rows) of the maze."""
        return self._height

    @property
    def seed(self) -> int | None:
        """Optional[int]: Random seed used for maze generation."""
        return self._seed

    @property
    def direction(self) -> dict[str, tuple[int, ...]]:
        """dict[str, tuple[int, ...]]: Mapping of direction.

        Names to offsets and bit indices.
        """
        return self._direction

    @property
    def perfect(self) -> bool:
        """bool: True if the maze is generated without loops (perfect maze)."""
        return self._perfect

    @property
    def algorithm_name(self) -> str:
        """str: Algorithm name used to generate the maze."""
        return self._algo_name

    @property
    def solution(self) -> Optional[tuple[List[Tuple[int, int]], str]]:
        """Optional[tuple[List[Tuple[int, int]], str]].

        Solved path and directional metadata.

        Calculates and caches the solution lazily upon access.

        Raises:
            RuntimeError: If accessed before `generate()` has been called.
        """
        if not self._generated:
            raise RuntimeError(
                "Cannot access solution before generate() has been called"
            )
        if self._solution is None:
            self._solution = self._solver.solve(
                self.maze, self._entry, self._exit)
        return self._solution

    @abstractmethod
    def generate(self) -> None:
        """Generate the maze structure.

        Subclasses must implement this method and call
        `_finalize()` at the end.
        """
        ...
