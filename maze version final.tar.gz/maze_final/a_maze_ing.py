"""Entry point module for the Maze Engine GUI application.

This script parses command-line arguments to locate the
maze configuration file, initializes the main window interface,
loads the initial maze layout, and runs the interactive display loop.
"""

import os
import sys
import time
import itertools
from pyfiglet import Figlet  # type: ignore[unused-ignore]


_src_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "src")
if _src_path not in sys.path:
    sys.path.insert(0, _src_path)

from gui.window import Window  # noqa: E402
try:
    from mazegen import Config, ConfigError
except ModuleNotFoundError:
    print("Use the command : make run")


def animation_welcome(
    duration: float = 5.0, label: str = "Running maze"
) -> None:
    r"""Display a rotating ASCII spinner in the terminal for a duration.

    Prints a simple rotating character animation (``| / - \``) next to
    ``label`` for approximately ``duration`` seconds, then clears the
    line before returning.

    Args:
        duration: How long to run the spinner, in seconds. Defaults to
            5.0.
        label: Text displayed alongside the spinner. Defaults to
            "Running maze".
    """
    frames = "⠋⠙⠹⠸⠼⠴⠦⠧⠇⠏"
    end_time = time.time() + duration
    for frame in itertools.cycle(frames):
        if time.time() >= end_time:
            break
        sys.stdout.write(f"\r{label}... {frame}")
        sys.stdout.flush()
        time.sleep(0.1)
    sys.stdout.write(f"\r{label}... Done!{' ' * 10}\n")
    sys.stdout.flush()


def interpolate_color(
        start_rgb: tuple[int, int, int],
        end_rgb: tuple[int, int, int],
        factor: float
        ) -> tuple[int, int, int]:
    """Calculate intermediate RGB from facteur betwen 0 et 1."""
    r = int(start_rgb[0] + (end_rgb[0] - start_rgb[0]) * factor)
    g = int(start_rgb[1] + (end_rgb[1] - start_rgb[1]) * factor)
    b = int(start_rgb[2] + (end_rgb[2] - start_rgb[2]) * factor)
    return r, g, b


def show_title(
    text: str,
    font: str = "larry3d",
    start_color: tuple[int, int, int] = (255, 0, 128),
    end_color: tuple[int, int, int] = (0, 255, 255)
) -> None:
    """Print a PyFiglet ASCII art title with a linear RGB gradient.

    Renders the given text using the specified Figlet font and applies a
    horizontal color transition character by character across each line.

    Args:
        text: Text string to render in ASCII art.
        font: Name of the Figlet font to use. Defaults to "larry3d".
        start_color: Starting RGB color tuple for the gradient.
            Defaults to (255, 0, 128).
        end_color: Ending RGB color tuple for the gradient.
            Defaults to (0, 255, 255).
    """
    f = Figlet(font=font)
    rendered_text = f.renderText(text)
    lines = rendered_text.splitlines()

    max_length = max(len(line) for line in lines) if lines else 1

    for line in lines:
        colored_line = []
        for x, char in enumerate(line):
            if char.isspace():
                colored_line.append(char)
                continue

            factor = x / max(1, max_length - 1)
            r, g, b = interpolate_color(start_color, end_color, factor)

            ansi_code = f"\033[38;2;{r};{g};{b}m"
            colored_line.append(f"{ansi_code}{char}\033[0m")

        print("".join(colored_line))


def main() -> None:
    """Parse command-line arguments and runs the Maze application loop.

    Expects the configuration file path as the first positional argument.
    Initializes the Window instance, loads the maze file,
    and starts the event loop.

    Raises:
        Exception: Catches and logs any unexpected runtime
        errors during execution.
    """
    if len(sys.argv) < 2:
        print("Usage: python maze_engine.py <config_file>")
        sys.exit(1)
    config_file: str = sys.argv[1]
    try:
        Config.from_file(config_file)
    except ConfigError as e:
        print(f"Config file error: {e}")
        sys.exit(1)
    except (FileNotFoundError, OSError) as e:
        print(f"Cannot read config file: {e}")
        sys.exit(1)
    try:
        animation_welcome()
        window = Window()
        if not window.regenerate_maze(config_file):
            print("Failed to generate the initial maze.")
            sys.exit(1)
        window.run()
    except Exception as e:
        print(f"{type(e).__name__}: {e}")
        sys.exit(1)


if __name__ == "__main__":
    show_title("AMAZe.ING", "larry3d", (255, 255, 50), (250, 5, 55))
    main()
