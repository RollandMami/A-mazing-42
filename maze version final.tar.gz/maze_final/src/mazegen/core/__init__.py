"""Module that expose MazeGenerator Class."""

from .maze_engine import MazeGenerator


__all__ = ["MazeGenerator"]
