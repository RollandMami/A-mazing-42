"""Graphical user interface package."""
