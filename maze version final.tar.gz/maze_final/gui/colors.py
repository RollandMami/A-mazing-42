"""Module for color constants used for maze rendering and UI components."""

BACKGROUND_COLOR = 0x202020
WALL_COLOR = 0xFFFFFF
ENTRY_COLOR = 0x00FF00
EXIT_COLOR = 0xFF0000
PATH_COLOR = 0xFFFF00
TEXT_COLOR = 0xFFFFFF
FORTY_TWO_COLOR = 0xFFFFFF
PALETTE = [
            0xFF0000,
            0x00FF00,
            0x0000FF,
            0xFFFF00,
            0xFF00FF,
            0x00FFFF,
        ]
